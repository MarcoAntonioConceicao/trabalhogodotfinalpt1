using Godot;
using System;

public partial class Jogador : CharacterBody2D
{
	private Vector2 velocity;
	private Vector2 direction;
	public Vector2 StartPosition;
	public Vector2 posicaomorte;
	public const float Speed = 300.0f;
	private bool isFacingRight = false;
	public int collectedDiamonds = 0; // Contador de diamantes coletados
	public int vidaAtual = 3;
	private int maxVida = 3;
	public const float JumpVelocity = -400.0f;
	public const float AirSpeedMultiplier = 0.5f; // Fator de redução da velocidade no ar
	// Get the gravity from the project settings to be synced with RigidBody nodes.
	public float gravity = ProjectSettings.GetSetting("physics/2d/default_gravity").AsSingle();
	private AnimatedSprite2D animate;
	private int jumpCount; // Número de pulos realizados
	public int maxJumpCount = 2; // Número máximo de pulos permitidos
	private Label vidaLabel;
	private Label diamondLabel;
	private AudioStreamPlayer somDePulo;
	private AudioStreamPlayer coletado;
	private AudioStreamPlayer dano;
	private bool noTrampolim = false;
	public override void _Ready()
	{
		
		animate = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
		StartPosition = GlobalPosition;
		posicaomorte = GlobalPosition;
		vidaLabel = GetNode<Label>("labelVida");
		diamondLabel = GetNode<Label>("labelDiamonds");
		somDePulo = GetNode<AudioStreamPlayer>("PULO");
		coletado = GetNode<AudioStreamPlayer>("DIAMANTE");
		dano = GetNode<AudioStreamPlayer>("DANO");
		UpdateVidaLabel();
	} //fim do ready

	public override void _PhysicsProcess(double delta)
	{
		//inercia inicial
		velocity = Velocity;

		// Add the gravity.
		if (!IsOnFloor())
			velocity.Y += gravity * (float)delta;

		// Handle Jump.
		  if (Input.IsActionJustPressed("ui_accept"))
	{
		if (IsOnFloor()) // Se estiver no chão, realiza o primeiro pulo
		{
			velocity.Y = JumpVelocity;
			jumpCount = 1;
			somDePulo.Play();
		
		}
		else if (jumpCount < maxJumpCount) // Se estiver no ar e ainda não atingiu o número máximo de pulos, realiza o pulo adicional
		{
			velocity.Y = JumpVelocity;
			jumpCount++;
			somDePulo.Play();
		}
   
	}

		// Get the input direction and handle the movement/deceleration.
		// As good practice, you should replace UI actions with custom gameplay actions.
		direction = Input.GetVector("ui_left", "ui_right", "ui_up", "ui_down");
		if (direction != Vector2.Zero)
		{
			if (!IsOnFloor()) // Aplica a redução de velocidade no ar
				velocity.X = direction.X * Speed * AirSpeedMultiplier;
			
			else
				velocity.X = direction.X * Speed;
		}
		else
		{
			//velocity.X = 0;
			velocity.X = Mathf.MoveToward(Velocity.X, 0, Speed * (float)(2 * delta));
		}

		Velocity = velocity;
		MoveAndSlide();

		Animation(velocity);
// Verificar se o personagem caiu abaixo da posição desejada
		if (GlobalPosition.Y > 600)
		{
			// Reposicionar o personagem no início
			GlobalPosition = StartPosition;

			// Reiniciar contadores e velocidades
			velocity = Vector2.Zero;
			jumpCount = 0;
PerderVida();
		checavida();
		UpdateVidaLabel();
		}
		
		FlipSprite(); // Chame a função FlipSprite no _PhysicsProcess para atualizar a escala da sprite

	if (AllDiamondsCollected())
				{
						GD.Print("Mapa concluído com sucesso!");
						GetTree().ChangeSceneToFile("mapa_2.tscn");
				  }
	} //fim do process

	private void Animation(Vector2 velocity)
	{
		if (!IsOnFloor())
		{
			animate.Play("jump");
		}
		else
		{
			if (velocity.X != 0)
			{
				animate.Play("run");
			}
			else
			{
				animate.Play("idle");
			}
		}
	}

	public void voltarinicio()
	{
		GlobalPosition = StartPosition;
	}

	private void FlipSprite()
{
	if (direction.X > 0 && !isFacingRight) // Verifica se a direção X é maior que zero e se a sprite está virada para a esquerda
	{
		isFacingRight = true; // Atualiza a direção
		animate.Scale = new Vector2(-1, 1); // Inverte a escala horizontal da sprite para a direita
	}
	else if (direction.X < 0 && isFacingRight) // Verifica se a direção X é menor que zero e se a sprite está virada para a direita
	{
		isFacingRight = false; // Atualiza a direção
		animate.Scale = new Vector2(1, 1); // Inverte a escala horizontal da sprite para a esquerda
	}
}
public void CollectDiamond()
	{
		collectedDiamonds++;
	coletado.Play();
	UpdateDiamondLabel(); // Atualiza o label de diamantes ao coletar um diamante
	}

	// Verifica se todos os diamantes foram coletados
	public bool AllDiamondsCollected()
	{
		return collectedDiamonds >= 5; // Supondo que existam 3 diamantes no total
	}

public void hit_checkpoint()
{
StartPosition = GlobalPosition;
}

public void Espetado() {
GlobalPosition = StartPosition;
PerderVida();
checavida();
UpdateVidaLabel();
GD.Print("Retornou ao ponto salvo");
}

private void UpdateVidaLabel()
{
	string coracoes = "";
	for (int i = 0; i < maxVida; i++)
	{
		if (i < vidaAtual)
			coracoes += "❤️"; // coração cheio
		else
			coracoes += "🖤"; // coração vazio
	}
	GetNode<Label>("labelVida").Text = coracoes;
}
private void PerderVida()
{
	vidaAtual -= 1;
	dano.Play();
}
private void checavida()
{
if (vidaAtual == 0) {
	GetTree().ChangeSceneToFile("gameover.tscn");
	GD.Print("Game Over! Reiniciando o jogo.");
	StartPosition = posicaomorte;
	GlobalPosition = posicaomorte;
	vidaAtual = 3;
	velocity = Vector2.Zero;
	jumpCount = 0;
	}
}

public void ganhavida()
{
if (vidaAtual != 3) {
vidaAtual = vidaAtual + 1;
coletado.Play();
UpdateVidaLabel();
}
}

private void UpdateDiamondLabel()
	{
		diamondLabel.Text = $"💎: {collectedDiamonds}"; // Atualiza o texto do label de diamantes
	}

public void superpulo()
{
velocity.Y = 3.0f * JumpVelocity;
}
}
